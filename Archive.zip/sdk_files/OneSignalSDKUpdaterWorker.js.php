<?php
	header("Service-Worker-Allowed: /");
	header("Content-Type: application/javascript");
?>
importScripts('https://cdn.onesignal.com/sdks/OneSignalSDK.js');
