function showProjectNumberHelper() {
	var tutorial_image = document.getElementById("project-number-helper");
	if (tutorial_image.style.display == 'none') {
		tutorial_image.style.display = 'block';
	}
	else {
		tutorial_image.style.display = 'none';
	}
}

function showAppIDHelper() {
	var tutorial_image = document.getElementById("appID-helper");
	if (tutorial_image.style.display == 'none') {
		tutorial_image.style.display = 'block';
	}
	else {
		tutorial_image.style.display = 'none';
	}
}


function showRESTAPIHelper() {
	var tutorial_image = document.getElementById("rest-API-helper");
	if (tutorial_image.style.display == 'none') {
		tutorial_image.style.display = 'block';
	}
	else {
		tutorial_image.style.display = 'none';
	}
}