OneSignal WordPress Push Notification Plugin
====================================

OneSignal is a free push notification service for web and mobile apps. This plugin makes it easy to integrate your WordPress site with OneSignal Push Notifications.

- Download and install from the [WordPress Plugin Directory](https://wordpress.org/plugins/onesignal-free-web-push-notifications/)